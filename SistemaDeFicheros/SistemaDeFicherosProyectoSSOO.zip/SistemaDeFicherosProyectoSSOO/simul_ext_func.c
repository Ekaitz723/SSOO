#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "cabeceras.h"

int ArgDemasiadoLargo(char *arg) {
	if (strlen(arg) > LEN_NFICH ){
		printf("El nombre es muy largo.\n");
		return 1;
	}
	return 0;
}

void LlenarParaProbarElBinLlenado_si(EXT_BYTE_MAPS *ext_bytemaps, EXT_SIMPLE_SUPERBLOCK *ext_superblock) {
	int i;
	
	//Lleno los bytemaps.
	for(i=PRIM_BLOQUE_DATOS;i<MAX_BLOQUES_PARTICION;i++) {
		ext_bytemaps->bmap_bloques[i] = 1;
		ext_bytemaps->bmap_inodos[i] = 1;
	}
	ext_superblock->s_free_blocks_count = 0;
	ext_superblock->s_free_inodes_count = 0;
}

int InsufEspacio(EXT_SIMPLE_SUPERBLOCK *ext_superblock, unsigned char bmap_bloques[MAX_BLOQUES_PARTICION], unsigned short int *puntBloque, int cantBloquesNecesarios, char *nombre) {
	int i,bloquesLibres = 0;
	
	//Comprobamos si hay bloques y inodos libres:
	//
	//Aca dara true si s_free_inodes_count es 0.
	if(!(ext_superblock->s_free_inodes_count)) {
		printf("No hay espacio suficiente para copiar el fichero.");
		return 1;
	}
	//
	//Aca se dara true si s_free_blocks_count es menor que lo que necesitamos
	if(ext_superblock->s_free_blocks_count<cantBloquesNecesarios) {
		printf("No hay espacio suficiente para copiar el fichero.");
		return 1;
	}
	return 0;
}

int ComprobarComando(char *strcomando, char datosComando[][LONGITUD_COMANDO]) {
	if (!strcmp(strcomando, "\n")){
		return 1;
	}
	
	int i = 0;
	char *partes;
    
	//Se crea un array de char para guardar una copia de strcomando.
    char completo[strlen(strcomando)+1];
    
	//Se vuelca strcomando en completo.
	strcpy(completo, strcomando);
//	memcpy(completo, strcomando, strlen(strcomando)-1);
	completo[strlen(strcomando)-1] = '\0';
	
	//Se separa por partes. Guardo el primero
	partes = strtok(completo, " ");
	strcpy(datosComando[i++], partes);
	
	//Se guarda el comando por partes.
	while(i<DATOSCOMANDO) {
		if(partes = strtok(NULL, " ")) {
			strcpy(datosComando[i++], partes);
		}
		else {
			strcpy(datosComando[i++],"\n");
		}
	}
	return 0;
}

void LeeSuperBloque(EXT_SIMPLE_SUPERBLOCK *psup){
    printf("\nNumeros de Inodos: %i", psup -> s_inodes_count);
    printf("\nNumeros de Bloques: %i", psup -> s_blocks_count);
    printf("\nNumeros de Bloques Libres: %i", psup -> s_free_blocks_count);
    printf("\nNumeros de Inodos Libres: %i", psup -> s_free_inodes_count);
    printf("\nPrimer Bloque de Data: %i", psup -> s_first_data_block);
    printf("\nTamaino de Bloque: %i", psup -> s_block_size);
    //printf("Tamaino de Relleno: %i", psup -> s_relleno);
}

void Printbytemaps(EXT_BYTE_MAPS *ext_bytemaps){
    int i;
    /*Bit map de inodos (como en los ejercicios en clase)*/
    
    //Hacemos un bucle donde pasamos por todos los elemnetos que se guarda en el bmap_inodos
    printf("\nInodos :");
    for(i=0;i<MAX_INODOS;i++) {
        printf("%i ",ext_bytemaps->bmap_inodos[i]);
	}
	
    //Lo mismo de antes pero con Bitmaps de bloque
    printf("\nBloques [0-25] :");  
	for(i=0;i<CANTDATOSBITMAP;i++) {
        printf("%i ",ext_bytemaps->bmap_bloques[i]);
	}

    //Lo dejo comentado por razones... porque no se en teoria todo lo relacionado con relleno no deberia de existir...
    //Lo mismo de antes pero con Bitmaps de relleno (no se que es pero venga esto tiene un bitmap asique imprimir)
    /*printf("\nBitmap De Relleno: ");
    i -= SIZE_BLOQUE-(MAX_BLOQUES_PARTICION+MAX_INODOS)*sizeof(char);
    while(++i) {
        printf("%i ",ext_bytemaps->bmap_relleno[-i]);
	}
	*/
    
}

void Directorio(EXT_ENTRADA_DIR *directorio, EXT_SIMPLE_INODE blq_inodos[MAX_INODOS]){ 
	//Se iterara sobre los directorios usados o borrados hasta llegar a uno vacio (o al maximo de ellos en su defecto).
	//Esta expresion aparecera repetidas veces durante el codigo.
	// SOP	     BORRADO , i<MAX
	//		     00  01  11  10
	// NULL   0  0   1   1   0
	//		  1  0   0   1   0
	
	int i = 0;
	while( (directorio->dir_inodo != NULL_INODO || strcmp(directorio->dir_nfich, "" ) == 0)  && i++ < MAX_INODOS ) {
		//Si el nombre de 
		if( strcmp(directorio->dir_nfich, "") == 0 || strcmp(directorio->dir_nfich, ".") == 0 )
			++directorio;
		else {
			//Info de directorio.
			printf("[%s]\t| tamaino: %i\t| inodo: %i  bloques: ", directorio->dir_nfich, blq_inodos[directorio->dir_inodo].size_fichero, directorio->dir_inodo);

			//Bloques que ocupa el directorio.
            printf(" [%i]\n",ContarBloques(blq_inodos[(directorio++)->dir_inodo].i_nbloque,1,NULL));
		}
	}
}

int ContarBloques(unsigned short int puntBloque[MAX_NUMS_BLOQUE_INODO], int verbose, int *bloquesLibres) {
	
	//Ahora inecesario, ya que no podemos alterar los archivos. Despues de la entrega le seguiremos dando a este codigo asique dejamos este int comentado.
//	int jbloquesLibres=0;
	int j;
	for(j=0;(*(puntBloque+j) != NULL_BLOQUE) && j < MAX_NUMS_BLOQUE_INODO;j++) {
		if(verbose)
			printf("%i ", *(puntBloque+j));
		if(bloquesLibres != NULL) {
			bloquesLibres[j] = *(puntBloque+j);
		}
	}
	return j;
}

int BuscaFich(EXT_ENTRADA_DIR *directorio, char *nombre) {
	
    //bucle para buscar todos los directorios
    int i;
    
    //Recorre el directorio.
    for (i = 0; (directorio->dir_inodo != NULL_INODO || strcmp(directorio->dir_nfich, "" ) == 0)  && i < MAX_INODOS; i++) {
        //Se compara el nombre del fichero con todos los existentes y si coinciden con el correcto, se devulve i, que es la de verces que se tuvo que recorrer este bucle para encontrar en nombre
        if(!strcmp(nombre,directorio->dir_nfich)){
            return i;
        }
        
        //Sino, accede al siguiente directorio y sigue buscando
        ++directorio;
    }
    return 0;
}

int Imprimir(EXT_ENTRADA_DIR *directorio, EXT_BLQ_INODOS *inodos, EXT_DATOS *memdatos, char *nombre){
	
	int i,j,cantBloques;
	int bloquesImprimir[MAX_NUMS_BLOQUE_INODO];
	
	//Comprobamos que el fichero a imprimir existe.
    if((cantBloques = BuscaFich(directorio,nombre))) {
		
		//Consigue los bloques.
		cantBloques = ContarBloques(inodos->blq_inodos[(directorio+cantBloques)->dir_inodo].i_nbloque,0,bloquesImprimir);
		
		//Bucle donde imprime los bloques.
	    //No hace falta comprobar si es nulo ya que cantBloques es exactamente el numero de bloques que tenemos que imprimir.
	    for ( i = 0; i < cantBloques; i++) {
	    	
	    	//Hoy en cuarto milenio, el x = x + a que no es lo mismo que x = x + a.
	    	//Ya me di cuenta de por que pero me hacia gracia el comentario asique lo dejo.
			memdatos = memdatos + bloquesImprimir[i]-PRIM_BLOQUE_DATOS;
	    	
	    	//EOF es 0.
	    	for (j=0; j<= SIZE_BLOQUE && memdatos->dato[j] != 0; j++){
				printf("%c", memdatos->dato[j]);
			}
			
			//le restauramos la posicion de los datos para ir a l siguiente linea (metadatos - .... y +4 al final) pero esto es solo una teria hasta un punto y me ha funcionado con esto
			memdatos = memdatos - bloquesImprimir[i]+PRIM_BLOQUE_DATOS;
		}
	    printf("\n");
	    return 1;
    }
    if (strcmp(nombre, "\n") == 0){
		printf("No me seas, ponme un fichero que leer\n");
		return 0;
	}
	printf("\nNo existe\n");
	return 0;
}

int Renombrar(EXT_ENTRADA_DIR *directorio, char *nombre, char *nuevo){
	int i;

	//Se comprueba que no exista ya.
	if (BuscaFich(directorio, nuevo)){
		printf("%s ya existe\n",nombre);
		return 0;
	}
	
	//Si existe el que quieres renombrar, lo hace.
	if (BuscaFich(directorio, nombre)){
		directorio += BuscaFich(directorio, nombre);
		strcpy(directorio->dir_nfich, nuevo);
		return 1;
	}
	//Sino, no.
	printf("Fichero no encontrado\n");
	return 0;
}

int Borrar(EXT_ENTRADA_DIR *directorio, EXT_BLQ_INODOS *inodos, EXT_BYTE_MAPS *ext_bytemaps, EXT_SIMPLE_SUPERBLOCK *ext_superblock, char *nombre){
	if (strcmp(nombre, "\0") == 0){
		printf("Nombre no valido\n");
		return 0;
	}
	
	int i,a;
	int lugar = BuscaFich(directorio, nombre);
	int cantBloquesUsados;
	int bloquesUsados[MAX_NUMS_BLOQUE_INODO];
	
	//Vamos a busacar al suertudo
	if (lugar){
		//Sumamos lugar a directorio para moverlo.
		directorio += lugar;
		
		//Conseguimos los bloques ocupados y la cantidad de ellos.
		cantBloquesUsados = ContarBloques(inodos->blq_inodos[directorio->dir_inodo].i_nbloque,0,bloquesUsados);
		
		//Cambio los bytemaps y los tamainos:
		//(bmap inodos).
		ext_bytemaps->bmap_inodos[directorio->dir_inodo] = 0;
		//(tam fich).
		inodos->blq_inodos[directorio->dir_inodo].size_fichero = 0;
		//(bmap bloques).
		for(i=0; i<cantBloquesUsados; i++) {
			ext_bytemaps->bmap_bloques[bloquesUsados[i]] = 0;
		}
		
		//Aumento el recuento de bloques libres y la cantidad de inodos.
		ext_superblock->s_free_blocks_count+=cantBloquesUsados;
		ext_superblock->s_free_inodes_count+=1;

		
		//Le vacio el nombre en el directorio. Este valor lo pensaremos como "Borrado pero no nuevo".
		strcpy(directorio->dir_nfich , "");


		//Se vuelve a iterar sobre los bloques usados por el fichero que estamos borrando. Esta vez para comprobar s_first_datab_lock.
		//Si es el primer data block, itera sobre los bloques de la particion apartir del 4. Si esta ocupado (el bitmap), se guarda como el primer bloque de datos.
		for(i = 0; i < cantBloquesUsados; i++){
			if(bloquesUsados[i] == ext_superblock->s_first_data_block){
				
				for(a = PRIM_BLOQUE_DATOS; a<=MAX_BLOQUES_PARTICION; a++){
					if(ext_bytemaps->bmap_bloques[a] == 1){
						
						ext_superblock->s_first_data_block = a;
						break;
					}
				}
			}
			
			//Pongo a NULL los bloques usados una vez compruebo que no es el s_first_data_block.
			bloquesUsados[i] = NULL_BLOQUE;
		}
		
		//Y por ultimo (para hacerlo una vez ya no necesitemos lo que vamos a poner a 0 en el bytemap, tal y como hicimos con bloquesUsados, pongo a NULL el inodo.
		directorio->dir_inodo = NULL_INODO;
		
		return 1;
	}
	else{
		printf("El fichero no existe\n");
		return 0;
	}
}

int Copiar(EXT_ENTRADA_DIR *directorio, EXT_BLQ_INODOS *inodos, EXT_BYTE_MAPS *ext_bytemaps, EXT_SIMPLE_SUPERBLOCK *ext_superblock, EXT_DATOS *memdatos, char *nombre, char *nuevo) {
	int i, a, lugar, cantBloquesUsados;
	int bloquesUsados[MAX_NUMS_BLOQUE_INODO];
	EXT_ENTRADA_DIR *directorioMas;
	
	//Si existe el fichero:
	if(lugar = BuscaFich(directorio, nombre)) {
		//Muevo directorio lugar posiciones.
		directorioMas=(directorio+lugar);
		
		//Comprobamos si hay suficiente espacio,
		//y si lo hay ya conseguimos los bloques ocupados y la cantidad de ellos con ContarBloques.
		if(InsufEspacio(ext_superblock, ext_bytemaps->bmap_bloques, inodos->blq_inodos[(directorio+BuscaFich(directorio,nombre))->dir_inodo].i_nbloque,cantBloquesUsados = ContarBloques(inodos->blq_inodos[directorioMas->dir_inodo].i_nbloque,0,bloquesUsados), nombre)) {
		    return 0;
		}

		//Si el bloque primero de datos no es el primer bloque de datos, ahora si.
		if(!ext_bytemaps->bmap_bloques[PRIM_BLOQUE_DATOS]){
			ext_superblock->s_first_data_block = PRIM_BLOQUE_DATOS;
		}
		
		//Busco la nueva posicion de directorio.
		for(i=0;(directorio->dir_inodo != NULL_INODO || strcmp(directorio->dir_nfich, "" ) == 0)  && i < MAX_INODOS ;i++) {
			++directorio;
		}
		
		//Decremento el recuento de bloques libres y la cantidad de inodos.
		ext_superblock->s_free_blocks_count-=cantBloquesUsados;
		ext_superblock->s_free_inodes_count-=1;
		
		
		//Conseguimos con esto el nuevo directorio.
		//Prioriza los que estan mas cercanos al s_first_data_block, los que estuvieron previamente no nulos.
		for (i=PRIM_BLOQUE_DATOS; !(i>MAX_INODOS); i++){
			if(!ext_bytemaps->bmap_inodos[i]){
				break;
			}
		}
		//
		//La i al salir tiene el valor del inodo en el que se ainadira.
		directorio->dir_inodo = i;
		//
		//Una vez sabemos su inodo, copio el nombre y el tamaino.
		strcpy(directorio->dir_nfich, nuevo);
		inodos->blq_inodos[directorio->dir_inodo].size_fichero = inodos->blq_inodos[directorioMas->dir_inodo].size_fichero;
		
		for(i = PRIM_BLOQUE_DATOS, a = 0; a<cantBloquesUsados && i>MAX_BLOQUES_DATOS;) {
			//Si esta en el bitmap como 0:
			if(!ext_bytemaps->bmap_bloques[i]) {
				
				//Se ainade un bloque.
				inodos->blq_inodos[directorio->dir_inodo].i_nbloque[a++] = i;
				
				//Cambia a 1.
				ext_bytemaps->bmap_bloques[i++]=1;
			}
		}
		
		//Al final de hacer todo lo necesario, ainadimos la cantidad necesaria de bloques libres al inodo, y despues se les cambia el bitmap.
		for(i = PRIM_BLOQUE_DATOS, a = 0; i<=MAX_BLOQUES_PARTICION && a<cantBloquesUsados; i++){
			//Si esta en el bitmap como 0:
			if(!ext_bytemaps->bmap_bloques[i]){
				ext_bytemaps->bmap_bloques[i] = 1;
				inodos->blq_inodos[directorio->dir_inodo].i_nbloque[a++] = i;			
			}
		}
		
		//Por ultimo (antes de copiar), por la misma razon que los bloques, ainadimos en inodo.
		ext_bytemaps->bmap_inodos[directorio->dir_inodo] = 1;
		//
		//Una vez hechas esas gestiones, copiamos los bloques.
		for(i=0;i<cantBloquesUsados;++i){
			
			//Se le resta PRIM_BLOQUE_DATOS ya que empieza apartir de ahi.
			memdatos = memdatos - PRIM_BLOQUE_DATOS;
			
			//Y ahora pasamos los datos de bloquesUsados (del original) al nuevo hasta encontrarnos con EOOF (0) o que se termine (SIZE_BLOQUE 512).
			for(a = 0; a < SIZE_BLOQUE && (memdatos + bloquesUsados[i])->dato[a] != 0; a++) {
				(memdatos + inodos->blq_inodos[directorio->dir_inodo].i_nbloque[i])->dato[a] = (memdatos + bloquesUsados[i])->dato[a];
			}
			
			//Ahora si, por ultimo de verdad, le ainadimos un EOF (0) al final SOLO SI a acabo antes de que terminase el bloque, 
			if (a<SIZE_BLOQUE){
				memdatos->dato[a] = 0;
			}
			//Se restaura memdatos.
			memdatos = memdatos + PRIM_BLOQUE_DATOS;
		}
	}
	return 1;
}

void GrabarSuperBloque(EXT_SIMPLE_SUPERBLOCK *ext_superblock, FILE *fich){
	//SIZE_BLOQUE y 1 intercambiados porque es m�s eficiente.
	fwrite(ext_superblock, SIZE_BLOQUE, 1, fich);
}

void GrabarByteMaps(EXT_BYTE_MAPS *ext_bytemaps, FILE *fich){
    fwrite(ext_bytemaps, SIZE_BLOQUE, 1, fich);
}

void Grabarinodosydirectorio(EXT_ENTRADA_DIR *directorio, EXT_BLQ_INODOS *inodos, FILE *fich){
	fwrite(inodos, SIZE_BLOQUE, 1, fich);
    fwrite(directorio, SIZE_BLOQUE, 1, fich);
}

void GrabarDatos(EXT_DATOS *memdatos, FILE *fich){
    fwrite(memdatos, SIZE_BLOQUE, MAX_BLOQUES_DATOS, fich);
}
