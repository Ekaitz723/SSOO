#include <stdio.h>

/***************/
//#define tama�o cantidad, numero
/* Tama�o de bloque.
 * Tama�o maximo de inodos.
 * Tama�o maximo de ficheros.
 * Tama�o maximo de bloques datos.
 * Tama�o de los primeros bloques.
 * Tama�o maximo de bloques en particion.
 * Tama�o maximo de bloques por inodo.
 * Longitud maxima de nombre de fichero.
 * Valor nulo de inodo.
 * Valor nulo de bloque.
 * Cantidad de datos en comando.
 * Cantidad de elementos imprimibles del bytemap de bloques.
 * Longitud de comando.
 */
#define SIZE_BLOQUE 512
#define MAX_INODOS 24
#define MAX_FICHEROS 20
#define MAX_BLOQUES_DATOS 96
#define PRIM_BLOQUE_DATOS 4
#define MAX_BLOQUES_PARTICION MAX_BLOQUES_DATOS+PRIM_BLOQUE_DATOS
#define MAX_NUMS_BLOQUE_INODO 7
#define LEN_NFICH 17
#define NULL_INODO 0xFFFF
#define NULL_BLOQUE 0xFFFF
#define DATOSCOMANDO 3
#define CANTDATOSBITMAP 25
#define LONGITUD_COMANDO 100

//Solo porque puedo :v
typedef char* String;

/***************/

/* Estructura del superbloque */
typedef struct {
  unsigned int s_inodes_count;          /* inodos de la partición */
  unsigned int s_blocks_count;          /* bloques de la partición */
  unsigned int s_free_blocks_count;     /* bloques libres */
  unsigned int s_free_inodes_count;     /* inodos libres */
  unsigned int s_first_data_block;      /* primer bloque de datos */
  unsigned int s_block_size;        /* tamaño del bloque en bytes */
  unsigned char s_relleno[SIZE_BLOQUE-6*sizeof(unsigned int)]; /* relleno a 0's*/
} EXT_SIMPLE_SUPERBLOCK;

/* Bytemaps, caben en un bloque */
typedef struct {
  unsigned char bmap_bloques[MAX_BLOQUES_PARTICION];
  unsigned char bmap_inodos[MAX_INODOS];  /* inodos 0 y 1 reservados, inodo 2 directorio */
  unsigned char bmap_relleno[SIZE_BLOQUE-(MAX_BLOQUES_PARTICION+MAX_INODOS)*sizeof(char)];
} EXT_BYTE_MAPS;

/* inodo */
typedef struct {
  unsigned int size_fichero;
  unsigned short int i_nbloque[MAX_NUMS_BLOQUE_INODO];
} EXT_SIMPLE_INODE;

/* Lista de inodos, caben en un bloque */
typedef struct {
  EXT_SIMPLE_INODE blq_inodos[MAX_INODOS];
  unsigned char blq_relleno[SIZE_BLOQUE-MAX_INODOS*sizeof(EXT_SIMPLE_INODE)];
} EXT_BLQ_INODOS;

/* Entrada individual del directorio */
typedef struct {
  char dir_nfich[LEN_NFICH];
  unsigned short int dir_inodo;
} EXT_ENTRADA_DIR;

/* Bloque de datos */
typedef struct{
  unsigned char dato[SIZE_BLOQUE]; 	
} EXT_DATOS;

/***************/

/*Comprueba si los nomrbes de los ficheros (char*) son demasiado largos.
 *Devuelve true si es que es muy largo. False en el contrario.
 */
int ArgDemasiadoLargo(char *arg);

/*Llena los bytemaps de 1, y pone a 0 los bloques e inodos libres.
 *Es void.
 */
void LlenarParaProbarElBinLlenado_si(EXT_BYTE_MAPS *ext_bytemaps, EXT_SIMPLE_SUPERBLOCK *ext_superblock);

/*Devuelve true si es que no es posible crear otro fichero (copiar el fichero).
 *Recoge el tamaino ya que donde lo vamos a usar ya tendremos el tamaino. En otras funciones si llegasemos a usarlo (no) le ponemos como parametro ContarBloques(LOS PARAMETROS NECESARIOS).
 */
int InsufEspacio(EXT_SIMPLE_SUPERBLOCK *ext_superblock, unsigned char bmap_bloques[MAX_BLOQUES_PARTICION], unsigned short int *puntBloque, int cantBloquesNecesarios, char *nombre);

/*Comprueba si el comando escrito es veraz.
 *Devuelve true cuando no es bueno. False en el contrario.
 */
int ComprobarComando(char *strcomando, char datosComando[][LONGITUD_COMANDO]);

/*Imprimir la informacion del superbloque.
 *Es void.
 */
void LeeSuperBloque(EXT_SIMPLE_SUPERBLOCK *psup);

/*Imprime los bytemaps de Inodos y Bloques.
 *Es void.
 */
void Printbytemaps(EXT_BYTE_MAPS *ext_bytemaps);

/*Muestra los ficheros existentes, con sus tama�os, inodos y bloques ocupados.
 *Es void.
 */
void Directorio(EXT_ENTRADA_DIR *directorio, EXT_SIMPLE_INODE blq_inodos[MAX_INODOS]);

/*Cuenta y nombra los bloques usados por un fichero.
 *int *bloquesLibres debe recojer los numeros de bloque que conseguimos en la funcion.
 *Devuelve la cantidad de bloques que ocupa un fichero
 */
int ContarBloques(unsigned short int puntBloque[MAX_NUMS_BLOQUE_INODO], int verbose, int *bloquesLibres);

/*Un poco como indica el nombre, se busca el fichero deseado y devuelve la posicion del fichero (es lo que se me ocurrio ya que devuelve un int)
 *Devuelve true si existe el fichero. False de lo contrario.
 */
int BuscaFich(EXT_ENTRADA_DIR *directorio, char *nombre);

/*Imprime los datos de un fichero (el texto que tienen guardados).
 *Devuelve true si se pudo imprimir. False de lo contrario.
 */
int Imprimir(EXT_ENTRADA_DIR *directorio, EXT_BLQ_INODOS *inodos, EXT_DATOS *memdatos, char *nombre);

/*Renombra el fichero exigido.
 *Devuelve true si se pudo renombrar. False de lo contrario.
 */
int Renombrar(EXT_ENTRADA_DIR *directorio, char *nombre, char *nuevo);

/*Borra el fichero exigido.
 *Devuelve true si se pudo borrar. False de lo contrario.
 */
int Borrar(EXT_ENTRADA_DIR *directorio, EXT_BLQ_INODOS *inodos, EXT_BYTE_MAPS *ext_bytemaps, EXT_SIMPLE_SUPERBLOCK *ext_superblock, char *nombre);

/*Copia un archivo (con sus nuevos bloques, inodo, datos..., no una referencia al mismo inodo).
 *Devuelve true si se pudo copiar. False en lo contrario.
 */
int Copiar(EXT_ENTRADA_DIR *directorio, EXT_BLQ_INODOS *inodos, EXT_BYTE_MAPS *ext_bytemaps, EXT_SIMPLE_SUPERBLOCK *ext_superblock, EXT_DATOS *memdatos, char *nombre, char *nuevo);

/*Graba los datos del supebloque.
 *Es void.
 */
void GrabarSuperBloque(EXT_SIMPLE_SUPERBLOCK *ext_superblock, FILE *fich);

/*Graba Los bytemaps.
 *Es void.
 */
void GrabarByteMaps(EXT_BYTE_MAPS *ext_bytemaps, FILE *fich);

/*Graba los inodos de los directorios.
 *Es void.
 */
void Grabarinodosydirectorio(EXT_ENTRADA_DIR *directorio, EXT_BLQ_INODOS *inodos, FILE *fich);

/*Graba los datos.
 *Es void.
 */
void GrabarDatos(EXT_DATOS *memdatos, FILE *fich);
