#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "cabeceras.h"

int main() {
	
	char comando[LONGITUD_COMANDO];
	char datosComando[DATOSCOMANDO][LONGITUD_COMANDO];
	
	int i,j;
	unsigned long int m;
    EXT_SIMPLE_SUPERBLOCK ext_superblock;
    EXT_BYTE_MAPS ext_bytemaps;
    EXT_BLQ_INODOS ext_blq_inodos;
    EXT_ENTRADA_DIR directorio[MAX_FICHEROS];
    EXT_DATOS memdatos[MAX_BLOQUES_DATOS];
    EXT_DATOS datosfich[MAX_BLOQUES_PARTICION];
    int entradadir;
    int grabardatos;
    FILE *fent;
    
     
    // Lectura del fichero completo de una sola vez
    fent = fopen("particion.bin","r+b");
    fread(&datosfich, SIZE_BLOQUE, MAX_BLOQUES_PARTICION, fent);    
    memcpy(&ext_superblock,(EXT_SIMPLE_SUPERBLOCK *)&datosfich[0], SIZE_BLOQUE);
    memcpy(&directorio,(EXT_ENTRADA_DIR *)&datosfich[3], SIZE_BLOQUE);
    memcpy(&ext_bytemaps,(EXT_BLQ_INODOS *)&datosfich[1], SIZE_BLOQUE);
    memcpy(&ext_blq_inodos,(EXT_BLQ_INODOS *)&datosfich[2], SIZE_BLOQUE);
    memcpy(&memdatos,(EXT_DATOS *)&datosfich[4],MAX_BLOQUES_DATOS*SIZE_BLOQUE);
    
	
    // Buce de tratamiento de comandos
    for (;;){
    	printf("\n");
		do {
			printf (">> ");
			fflush(stdin);
			fgets(comando, LONGITUD_COMANDO, stdin);
		} while (ComprobarComando(comando,datosComando));

		printf("\n");
		//printf("�%s�%s�%s�%i�",datosComando[0],datosComando[1],datosComando[2],BuscaFich(directorio,"pato"));
		
	    if (!strcmp(datosComando[0],"salir")) {
	    	//No hace falta aca grabar datos ya que en caso de haber hecho algo que necesite grabar datos, ya se guardaron.
            fclose(fent);
            return 0;
   		}
    	else if (!strcmp(datosComando[0],"bytemaps")) {
            Printbytemaps(&ext_bytemaps);
            continue;
   		}
    	else if (!strcmp(datosComando[0],"dir")) {
    		Directorio(directorio, ext_blq_inodos.blq_inodos);
            continue;
   		}
    	else if (!strcmp(datosComando[0],"rename")) {
    		if(ArgDemasiadoLargo(datosComando[1]) || ArgDemasiadoLargo(datosComando[2]) || !strcmp(datosComando[2], "\n")) {
    			continue;
			}
			if(Renombrar(directorio, datosComando[1], datosComando[2]))
    			grabardatos = 1;
    	}
    	else if (!strcmp(datosComando[0],"imprimir")) {
            Imprimir(directorio, &ext_blq_inodos, memdatos, datosComando[1]);
            continue;
   		}
    	else if (!strcmp(datosComando[0],"remove")) {
    		if(ArgDemasiadoLargo(datosComando[1])) {
    			continue;
			}
            if(Borrar(directorio, &ext_blq_inodos, &ext_bytemaps, &ext_superblock, datosComando[1]))
    			grabardatos = 1;
		}
    	else if (!strcmp(datosComando[0],"copy")) {
    		if(ArgDemasiadoLargo(datosComando[1]) || ArgDemasiadoLargo(datosComando[2]) || !strcmp(datosComando[2], "\n")) {
				continue;
			}
			if(Copiar(directorio, &ext_blq_inodos, &ext_bytemaps, &ext_superblock, memdatos, datosComando[1], datosComando[2]))
    			grabardatos = 1;
    	}
    	else if (!strcmp(datosComando[0],"info")) {
            LeeSuperBloque(&ext_superblock);
            continue;
   		}
   		else if (!strcmp(datosComando[0],"efarElBin")) {
   			LlenarParaProbarElBinLlenado_si(&ext_bytemaps, &ext_superblock);
   			printf("\n\nF en el chat\n\n");
   			grabardatos = 1;
		   }
   		else if (!strcmp(datosComando[0],"?")) {
            printf("Puedes hacer:\n\tinfo\n\tbytemaps\n\tdir\n\trename\n\timprimir\n\tremove\n\tcopy\n\tsalir\n");
            continue;
   		}
    	else {
    		printf("Comando desconocido, prueba con ?\n");
    		continue;
    	}
    	
        //Escritura de metadatos en comandos rename, remove, copy.
        //Los llamamos en este orden para ahorrarnos el fseek.
        //Entre las funciones de arriba, ninguna implementa realmente el guardado. Lo guardan de forma "local" (en el programa), pero no en el bin, hasta que llegan aqui.
        if (grabardatos) {
        	//Rewind de la ultima vez que se hizo el grabado.
        	rewind(fent);
        	
        	
        	GrabarSuperBloque(&ext_superblock, fent);
        	GrabarByteMaps(&ext_bytemaps, fent);
        	Grabarinodosydirectorio(directorio, &ext_blq_inodos, fent);
        	GrabarDatos(memdatos, fent);
        	
        	grabardatos = 0;
		}
    }
}


